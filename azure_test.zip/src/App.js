import React from 'react';

import Formulario from './Componentes/Formulario';

const App = () => {
  return ( 
    <>
        <Formulario />
    </>
   );
}
 
export default App;