const theme = {
    fondo: '#F9F9F9',
    colorPrimario: '#5B69E2',
    colorSecundario: '#000',
    verde: '#43A854',
    rojo: '#E34747',
    grisClaro: '#E8EFF1',
    grisClaro2: '#CBDDE2',
    azulClaro: '#8792F1'
}

export default theme;